//
//  ContentView.swift
//  LiveCamera
//
//  Created by ADMIN UNACH on 11/09/24.
//

// INTERFAZ PRINCIPAL

import SwiftUI

struct ContentView: View {
    
    @State private var imageData: Data? = nil
    @State private var showCamera: Bool = false
    
    var body: some View {
        VStack{
            if let imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
            } else {
                Image(systemName: "photo")
                    .resizable()
                    .scaledToFit()
                    .foregroundColor(.gray)
            }
            Button("take photo"){
                showCamera = true
            }.padding()
        }.padding()
            .fullScreenCamera(isPresented: $showCamera, imageData: $imageData)
    }
}

#Preview {
    ContentView()
}
