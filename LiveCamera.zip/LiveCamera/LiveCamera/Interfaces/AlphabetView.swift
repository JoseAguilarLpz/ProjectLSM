//
//  AlphabetView.swift
//  LiveCamera
//
//  Created by ADMIN UNACH on 12/09/24.
//

import SwiftUI

struct AlphabetView: View {
    var body: some View {
        ZStack{
            Color.black
            
            VStack{
                VStack{
                    Image(systemName: "book.fill")
                        .resizable()
                        .frame(width: 100, height: 50)
                    Text("ABCDARIO")
                        .font(.title)
                }
                
                VStack{
                    ZStack{
                        Color.gray
                        
                        Button(action: {
                            
                        }, label: {
                            VStack{
                                Rectangle()
                                    .frame(width: 150, height: 150)
                                Text("A")
                                    .font(.title)
                            }
                        })
                    }
                }
                
            }.foregroundColor(.white)
                .padding()
            
        }.ignoresSafeArea()
    }
}

#Preview {
    AlphabetView()
}
