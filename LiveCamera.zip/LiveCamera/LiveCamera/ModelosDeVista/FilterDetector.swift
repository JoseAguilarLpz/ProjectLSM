//
//  FilterDetector.swift
//  LiveCamera
//
//  Created by ADMIN UNACH on 12/09/24.
//

// MODELO PARA DETECTAR UNA POSE EN ESPECIFICO Y VERIFICAR LA APROXIMIDAD QUE TENGA

import Foundation
