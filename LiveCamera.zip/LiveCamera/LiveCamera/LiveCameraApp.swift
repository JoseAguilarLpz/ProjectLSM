//
//  LiveCameraApp.swift
//  LiveCamera
//
//  Created by ADMIN UNACH on 11/09/24.
//

import SwiftUI

@main
struct LiveCameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
